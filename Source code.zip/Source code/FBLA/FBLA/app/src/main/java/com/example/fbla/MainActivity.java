package com.example.fbla;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button ContactUsBtn = findViewById(R.id.ContactUsBtn);
        ContactUsBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent GoToContactUs = new Intent(getApplicationContext(), ContactUs.class);
                startActivity(GoToContactUs);
            }
        });
        Button factsbtn = findViewById(R.id.factsbtn);
        factsbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent GoToFacts = new Intent(getApplicationContext(), facts.class);
                startActivity(GoToFacts);
            }
        });
        Button joinbtn = findViewById(R.id.joinbtn);
        joinbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_VIEW);
                intent.setData(Uri.parse("https://drive.google.com/open?id=1Djd8r34YE8Y6A1hUUtzpCRj0MQaiXwMmC9C4pf4lhUI"));
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);
            }
        });
        Button calendarbtn = findViewById(R.id.calendarbtn);
        calendarbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent GoToCalendar = new Intent(getApplicationContext(), Calendar.class);
                startActivity(GoToCalendar);
            }
        });

    }
}
