package com.example.fbla;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class qna extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_qna);
    }
}
