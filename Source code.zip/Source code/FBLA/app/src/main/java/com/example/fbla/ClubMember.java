package com.example.fbla;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class ClubMember extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_club_member);
        //Button opens the list of events doc in google drive
        Button eventlistbtn = findViewById(R.id.eventlistbtn);
        eventlistbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_VIEW);
                intent.setData(Uri.parse("https://drive.google.com/open?id=1B2XQfhigZ5FB7UDd31hMjh67CgTE9yPq"));
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);
            }
        });
        //Button opens the Contact Us activity
        Button membercontact = findViewById(R.id.membercontact);
        membercontact.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent GoToContactUsm = new Intent(getApplicationContext(), ContactUs.class);
                startActivity(GoToContactUsm);
            }
        });
        //Button opens the Club Officers activity
        Button officers = findViewById(R.id.officers);
        officers.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent GoToContactUsm = new Intent(getApplicationContext(), officers.class);
                startActivity(GoToContactUsm);
            }
        });
        //Button opens the sign up document in google drive
        Button signup = findViewById(R.id.signup);
        signup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_VIEW);
                intent.setData(Uri.parse("https://drive.google.com/open?id=1N2vgmowCn6JpTKW1WuPYSdfRL4oaV9b-"));
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);
            }
        });
        //Button opens google calendar and adds the internet calendar of FBLA events
        Button eventcalendar = findViewById(R.id.eventcalendar);
        eventcalendar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_VIEW);
                intent.setData(Uri.parse("https://drive.google.com/open?id=1dtMuqTvHlaRplsrKR2s2V8yQf538BQtW"));
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);
            }
        });
    }
}
