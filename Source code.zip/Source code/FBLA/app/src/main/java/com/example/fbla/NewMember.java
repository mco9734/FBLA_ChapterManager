package com.example.fbla;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class NewMember extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_member);

        Button joinfbla = findViewById(R.id.joinfbla); //opens the join form in google drive
        joinfbla.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_VIEW);
                intent.setData(Uri.parse("https://drive.google.com/open?id=1_mF8BqVfBXScVk7Wyp9HFcU9g6q4AnWo"));
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);
            }
        });
        Button aboutfbla = findViewById(R.id.aboutfbla); //opens the FBLA-PBL website
        aboutfbla.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_VIEW);
                intent.setData(Uri.parse("https://fbla-pbl.org/about/"));
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);
            }
        });
        Button nmcontactus = findViewById(R.id.nmcontactus); //opens the contact us activity
        nmcontactus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent GoToContactUsnm = new Intent(getApplicationContext(), ContactUs.class);
                startActivity(GoToContactUsnm);
            }
        });
        Button qna = findViewById(R.id.qna); //opens the q and a activity
        qna.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent GoToqna = new Intent(getApplicationContext(), qna.class);
                startActivity(GoToqna);
            }
        });
    }
}
