package com.example.fbla;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class Login extends AppCompatActivity {

    private EditText Username;
    private EditText Password;
    private Button Login;
    private TextView Info;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        Button eula = findViewById(R.id.eula); //opens the EULA in google drive
        eula.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_VIEW);
                intent.setData(Uri.parse("https://drive.google.com/open?id=1Slkw_JeaQB6c10V1pKX3UCFobDfQKlLh"));
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);
            }
        });
        Button bugreport = findViewById(R.id.bugreport); //sends email with subject of FBLA to freedline
        bugreport.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_SENDTO); // it's not ACTION_SEND
                intent.putExtra(Intent.EXTRA_SUBJECT, "I found a bug!");
                intent.setData(Uri.parse("mailto:marcusotto8@gmail.com")); // or just "mailto:" for blank
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); // this will make such that when user returns to your app, your app is displayed, instead of the email app.
                startActivity(intent);
            }
        });

        Username = (EditText)findViewById(R.id.etUsername);
        Password = (EditText)findViewById(R.id.etPassword);
        Login = (Button) findViewById(R.id.loginbtn);
        Info = (TextView)findViewById(R.id.tvInfo);

        Info.setText("Enter Login Information");

        Button newmemberbtn = findViewById(R.id.newmemberbtn); //opens the new member activity
        newmemberbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent GoToNewMember = new Intent(getApplicationContext(), NewMember.class);
                startActivity(GoToNewMember);
            }
        });

        Login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                validate(Username.getText().toString(), Password.getText().toString());
            }
        });
    }

    private void validate(String userName, String userPassword){
        if((userName.equals("Admin")) && (userPassword.equals("1234"))) { //club adviser login credential check
            Intent intent = new Intent(Login.this, attendance.class);
            startActivity(intent);
        }if((userName.equals("clubmember")) && (userPassword.equals("password"))) { //club member login credential check
            Intent intent = new Intent(Login.this, ClubMember.class);
            startActivity(intent);


        }else{

            Info.setText("Incorrect Login Info"); //string is displayed if login info is incorrect


        }
        }
    }



